import pymongo

dbConn = pymongo.MongoClient("mongodb://localhost:27017/")  # connecting to the locally running MongoDB Instance